<?php $__env->startPush('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/admin-login.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('navbar'); ?>
<?php echo $__env->make('admin.layouts.partial.top-navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main-content'); ?>
  <div class="tile">
<center>
    <span>Login to <strong class="text-aqua">MADINA GROUP</strong></span>
</center>
  <div class="tile-header">
    <h2 style="color: white; opacity: .75; font-size: 4rem; display: flex; justify-content: center; align-items: center; text-align: center; height: 100%;"><small></small>Job Portal</h2>
  </div>
  
  <div class="tile-body">
    <form id="form" class="form-horizontal" method="POST" action="<?php echo e(route('admin.login')); ?>">
                        <?php echo e(csrf_field()); ?>

      <label class="form-input<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
        <i class="material-icons">person</i>
        
         <input id="email" type="email"  name="email" value="<?php echo e(old('email')); ?>" required autofocus >

        <?php if($errors->has('email')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('email')); ?></strong>
            </span>
        <?php endif; ?>
        <span class="label">Username</span>
        <span class="underline"></span>
      </label>
      
      <label class="form-input<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
        <i class="material-icons">lock</i>
        
        <input id="password" type="password" name="password" required >

        <?php if($errors->has('password')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('password')); ?></strong>
            </span>
        <?php endif; ?>
        <span class="label">Password</span>
        <div class="underline"></div>
      </label>
      <div class="checkbox">
                      <label>
                        <input type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>> Remember Me
                      </label>
                    </div>
      <div class="submit-container clearfix" style="margin-top: 2rem;">          
        <button id="submit" role="button" type="submit" class="btn btn-irenic float-right" tabindex="0">
          <span>SIGN IN</span>
        </button>
         <a class="btn btn-link" href="<?php echo e(route('admin.password.request')); ?>">
                            Forgot Your Password?
                        </a>
        <div class="login-pending">
          <div class=spinner>
            <span class="dot1"></span>
            <span class="dot2"></span>
          </div>
          
          <div class="login-granted-content">
            <i class="material-icons">done</i>
          </div>
        </div>
      </div>
    </form>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script type="text/javascript" src="<?php echo e(asset('js/admin-login.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>