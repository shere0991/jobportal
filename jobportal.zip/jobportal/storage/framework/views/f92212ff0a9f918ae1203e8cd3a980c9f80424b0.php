<div class="box">
        <div class="box-header with-border">
          <h3 class="box-title">Post Job</h3>

          <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip"
                    title="Collapse">
              <i class="fa fa-minus"></i></button>
            <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
              <i class="fa fa-times"></i></button>
          </div>
        </div>
       
        <form class="form-horizontal" action="<?php if (! empty(trim($__env->yieldContent('edit')))): ?><?php echo e(route('job-post.update',$editJob->id)); ?><?php else: ?><?php echo e(route('job-post.store')); ?>

        <?php endif; ?>" method="post">
            <?php echo e(csrf_field()); ?>

          <?php $__env->startSection('edit_method'); ?>
          <?php echo $__env->yieldSection(); ?>
          <div class="box-body">
           <div class="tab-pane" id="settings">
                  <div class="form-group<?php echo e($errors->has('company_id') ? ' has-error' : ''); ?>">
                    <label for="company_id" class="col-sm-2 col-md-2 control-label">Company/Industry Type</label>
                    <div class="col-sm-10 col-md-8">
                      <select name="company_id" id="company_id" class="form-control">
                        <?php if (! empty(trim($__env->yieldContent('edit')))): ?>
                          <option value="<?php echo $__env->yieldContent('companyid'); ?>"><?php echo $__env->yieldContent('companyname'); ?></option>
                        <?php endif; ?> 
                        <option>Select Company</option>
                        <?php $__currentLoopData = $company; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($c->id); ?>"><?php echo e($c->company_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                      <?php if($errors->has('company_id')): ?>
                          <label class="help-block">
                              <strong><?php echo e($errors->first('company_id')); ?></strong>
                          </label>
                        <?php endif; ?>
                    </div>
                  </div>
                  <div class="form-group<?php echo e($errors->has('JobTitle') ? ' has-error' : ''); ?>">
                    <label for="JobTitle" class="col-sm-2 col-md-2 control-label">Job Title</label>

                    <div class="col-sm-10 col-md-8">
                      <input name="JobTitle" type="text" value="<?php echo $__env->yieldContent('JobTitle'); ?>" class="form-control" id="JobTitle" placeholder="Job Title">
                      <?php if($errors->has('JobTitle')): ?>
                          <label class="help-block">
                              <strong><?php echo e($errors->first('JobTitle')); ?></strong>
                          </label>
                        <?php endif; ?>
                    </div>
                  </div>
                  <div class="form-group<?php echo e($errors->has('NoofVacancies') ? ' has-error' : ''); ?>">
                    <label for="NoofVacancies" class="col-sm-2 col-md-2 control-label">No. of Vacancies</label>

                    <div class="col-sm-10 col-md-8">
                      <input name="NoofVacancies" id="NoofVacancies"  type="number" value="<?php echo $__env->yieldContent('NoofVacancies'); ?>" class="form-control" placeholder="No. of Vacancies">
                      <?php if($errors->has('NoofVacancies')): ?>
                          <label class="help-block">
                              <strong><?php echo e($errors->first('NoofVacancies')); ?></strong>
                          </label>
                        <?php endif; ?>
                    </div>
                  </div>
                  <div class="form-group<?php echo e($errors->has('ApplyInstruction') ? ' has-error' : ''); ?>">
                    <label for="ApplyInstruction" class="col-sm-2 col-md-2 control-label">Apply Instruction(s)</label>

                    <div class="col-sm-10 col-md-8">
                       <textarea name="ApplyInstruction" id="ApplyInstruction"  class="form-control" id="ApplyInstruction" placeholder="Apply Instruction"><?php echo $__env->yieldContent('ApplyInstruction'); ?></textarea>
                        <?php if($errors->has('ApplyInstruction')): ?>
                          <label class="help-block">
                              <strong><?php echo e($errors->first('ApplyInstruction')); ?></strong>
                          </label>
                        <?php endif; ?>
                    </div>
                  </div>
                  <div class="form-group<?php echo e($errors->has('ApplicationDeadline') ? ' has-error' : ''); ?>">
                    <label for="ApplicationDeadline" class="col-sm-2 col-md-2 control-label">Application Deadline *</label>

                    <div class="col-sm-10 col-md-8">
                      <input name="ApplicationDeadline" id="datepicker" type="text" value="<?php echo $__env->yieldContent('ApplicationDeadline'); ?>" class="form-control" id="inputSkills" placeholder="Application Deadline">
                      <?php if($errors->has('ApplicationDeadline')): ?>
                          <label class="help-block">
                              <strong><?php echo e($errors->first('ApplicationDeadline')); ?></strong>
                          </label>
                        <?php endif; ?>
                    </div>
                  </div>
                  <div class="form-group<?php echo e($errors->has('AgeRangeFrom') ? ' has-error' : ''); ?>">
                    <label for="AgeRange" class="col-sm-2 col-md-2 control-label">Age Range</label>
                    <div class="col-sm-2 col-md-2">
                    <label for="AgeRangeFrom" class="control-label">From</label>
                      <input name="AgeRangeFrom" id="AgeRangeFrom"  type="number" class="form-control" value="<?php echo $__env->yieldContent('AgeRangeFrom'); ?>" placeholder="Age Range From">
                    <label for="AgeRangeTo" class="control-label">To</label>
                      <input name="AgeRangeTo" id="AgeRangeTo" value="<?php echo $__env->yieldContent('AgeRangeTo'); ?>" type="number" class="form-control" placeholder="Age Range To">
                       <?php if($errors->has('AgeRangeTo')): ?>
                          <label class="help-block">
                              <strong><?php echo e($errors->first('AgeRangeTo')); ?></strong>
                          </label>
                        <?php endif; ?>
                    </div>
                  </div>
                  
                  <div class="form-group<?php echo e($errors->has('Gender') ? ' has-error' : ''); ?>">  
                    <label for="Gender" class="col-sm-2 col-md-2 control-label">Gender</label>
                      <label for="MaleOnly" class="col-sm-2 col-md-2 control-label">
                      <input name="Gender" id="Gender" value="1" type="radio" name="r3" class="flat-red" <?php if (! empty(trim($__env->yieldContent('edit')))): ?> <?php if($editJob->Gender==1): ?> checked <?php else: ?> <?php endif; ?> <?php endif; ?>>
                      Male Only
                    </label>
                    <label for="FemaleOnly" class="col-sm-2 col-md-2 control-label">
                      <input name="Gender" id="Gender" value="2" type="radio" name="r3" class="flat-red"  <?php if (! empty(trim($__env->yieldContent('edit')))): ?> <?php if($editJob->Gender==2): ?> checked <?php else: ?> <?php endif; ?> <?php endif; ?>>
                      Female Only
                    </label>
                     <label for="FemaleOnly" class="col-sm-2 col-md-2 control-label">
                      <input name="Gender" id="Gender" value="3" type="radio" name="r3" class="flat-red"  <?php if (! empty(trim($__env->yieldContent('edit')))): ?> <?php if($editJob->Gender==3): ?> checked <?php else: ?> <?php endif; ?> <?php endif; ?>>
                      Any
                    </label>
                     <?php if($errors->has('Gender')): ?>
                          <label class="help-block">
                              <strong><?php echo e($errors->first('Gender')); ?></strong>
                          </label>
                        <?php endif; ?>
                  </div>
                      <!-- checkbox -->
                      <div class="form-group">
                        <label for="JobType" class="col-sm-2 col-md-2 control-label">Job Type</label>

                        <label for="FullTime" class="col-sm-2 col-md-2 control-label">
                          <input name="FullTime" id="FullTime" value="1" type="checkbox" class="flat-red" <?php if (! empty(trim($__env->yieldContent('edit')))): ?> <?php if(in_array(1,$jobType)==1): ?> checked <?php else: ?>  <?php endif; ?> <?php endif; ?>>
                          Full Time
                        </label>
                        <label for="PartTime" class="col-sm-2 col-md-2 control-label">
                          <input name="PartTime" id="PartTime" value="2"  type="checkbox" class="flat-red" <?php if (! empty(trim($__env->yieldContent('edit')))): ?>  <?php if(in_array(2,$jobType)==2): ?> checked <?php else: ?>  <?php endif; ?> <?php endif; ?>>
                          Part Time
                        </label>
                        <label for="Contractual" class="col-sm-2 col-md-2 control-label">
                          <input name="Contractual" id="Contractual" value="3"  type="checkbox" class="flat-red" <?php if (! empty(trim($__env->yieldContent('edit')))): ?> <?php if(in_array(3,$jobType)==3): ?> checked <?php else: ?>  <?php endif; ?> <?php endif; ?>>
                          Contractual
                        </label>
                        <label for="" class="col-sm-2 col-md-2 control-label">
                          <input name="Intern" id="Intern" value="4"  type="checkbox" class="flat-red"  <?php if (! empty(trim($__env->yieldContent('edit')))): ?> <?php if(in_array(4,$jobType)==4): ?> checked <?php else: ?>  <?php endif; ?> <?php endif; ?>>
                          Intern
                        </label>
                        </div> 
                         <div class="form-group">
                        <label for="JobLevel" class="col-sm-2 col-md-2 control-label">Job Level</label>
                        <label for="EntryLevel" class="col-sm-2 col-md-2 control-label">
                          <input name="EntryLevel" id="EntryLevel" value="1"  type="checkbox" class="flat-red" <?php if (! empty(trim($__env->yieldContent('edit')))): ?> <?php if(in_array(1,$jLevel)==1): ?> checked <?php else: ?>  <?php endif; ?> <?php endif; ?>>
                          Entry Level
                        </label>
                        <label for="MidLevel" class="col-sm-3 control-label">
                          <input name="MidLevel" id="MidLevel" value="2"  type="checkbox" class="flat-red" <?php if (! empty(trim($__env->yieldContent('edit')))): ?> <?php if(in_array(2,$jLevel)==2): ?> checked <?php else: ?>  <?php endif; ?> <?php endif; ?>>
                          Mid/Managerial Level
                        </label>
                        <label for="TopLevel" class="col-sm-2 col-md-2 control-label">
                          <input name="TopLevel"  type="checkbox" value="3" class="flat-red" <?php if (! empty(trim($__env->yieldContent('edit')))): ?> <?php if(in_array(3,$jLevel)==3): ?> checked <?php else: ?>  <?php endif; ?> <?php endif; ?>>
                          Top Level
                        </label> 
                        </div> 
                        <!-- checkbox -->
                        
                      <div class="form-group<?php echo e($errors->has('EducationalQualification') ? ' has-error' : ''); ?>">
                        <label for="EducationalQualification" class="col-sm-2 col-md-2 control-label">Educational Qualification</label>

                        <div class="col-sm-10 col-md-8">
                           <textarea name="EducationalQualification" class="form-control" id="EducationalQualification" placeholder="Educational Qualification"><?php echo $__env->yieldContent('EducationalQualification'); ?></textarea>
                          <?php if($errors->has('EducationalQualification')): ?>
                          <label class="help-block">
                              <strong><?php echo e($errors->first('EducationalQualification')); ?></strong>
                          </label>
                          <?php endif; ?>
                        </div>
                      </div>
                       <div class="form-group<?php echo e($errors->has('JobContext') ? ' has-error' : ''); ?>">
                    <label for="JobContext" class="col-sm-2 col-md-2 control-label">Job Context</label>

                    <div class="col-sm-10 col-md-8">
                       <textarea name="JobContext" id="JobContext" class="form-control" placeholder="Job Context"><?php echo $__env->yieldContent('JobContext'); ?></textarea>
                       <?php if($errors->has('JobContext')): ?>
                          <label class="help-block">
                              <strong><?php echo e($errors->first('JobContext')); ?></strong>
                          </label>
                          <?php endif; ?>
                    </div>
                  </div>
                   <div class="form-group<?php echo e($errors->has('JobDescription') ? ' has-error' : ''); ?>">
                    <label for="JobDescription" class="col-sm-2 col-md-2 control-label">Job Description/Responsibility</label>

                    <div class="col-sm-10 col-md-8">
                       <textarea name="JobDescription" id="JobDescription" class="form-control" placeholder="Job Description/Responsibility"><?php echo $__env->yieldContent('JobDescription'); ?></textarea>
                       <?php if($errors->has('JobDescription')): ?>
                          <label class="help-block">
                              <strong><?php echo e($errors->first('JobDescription')); ?></strong>
                          </label>
                          <?php endif; ?>
                    </div>
                  </div>
                   <div class="form-group">
                    <label for="AdditionalJobRequirements" class="col-sm-2 col-md-2 control-label">Additional Job Requirements</label>

                    <div class="col-sm-10 col-md-8">
                       <textarea name="AdditionalJobRequirements" name="AdditionalJobRequirements" class="form-control" placeholder="Additional Job Requirements"><?php echo $__env->yieldContent('AdditionalJobRequirements'); ?></textarea>

                    </div>
                  </div>
                  
                  <div class="form-group">
                    <label for="TotalYearsofExperience" class="col-sm-2 col-md-2 control-label">Total Years of Experience</label>
                    <div class="col-sm-8 col-md-8">
                      <div class="form-group<?php echo e($errors->has('ExperienceRequired') ? ' has-error' : ''); ?>">
                        <label for="" class="col-sm-3 col-md-3 control-label">
                        <input name="ExperienceRequired" id="ExperienceRequired" value="1" type="radio" name="r3" class="flat-red" <?php if (! empty(trim($__env->yieldContent('edit')))): ?> <?php if($ExperienceRequiredOption==1): ?> checked <?php else: ?> <?php endif; ?> <?php endif; ?>>
                      Experience Required
                    </label>
                      <label for="" class="col-sm-4 col-md-4 control-label">
                      <input name="ExperienceRequired" id="ExperienceRequired" value="0" type="radio" name="r3" class="flat-red" <?php if (! empty(trim($__env->yieldContent('edit')))): ?> <?php if($ExperienceRequiredOption==0): ?> checked <?php else: ?> <?php endif; ?> <?php endif; ?>>
                      No Experience Required
                    </label>
                    </div>
                    
                      
                    <div class="col-md-6">
                      <label for="MinimumExperience" class="control-label">Minimum Experience</label>
                      <input name="MinimumExperience" id="MinimumExperience"  type="number" value="<?php echo $__env->yieldContent('MinimumExperience'); ?>" class="form-control" placeholder="Minimum Experience">
                      <span id="ex-error"></span>
                    <label for="MaximumExperience" class="control-label">Maximum Experience</label>
                      <input name="MaximumExperience" id="MaximumExperience"  type="number" value="<?php echo $__env->yieldContent('MaximumExperience'); ?>" class="form-control" id="Maximum Experience" placeholder="Maximum Experience">
                      <span id="ex-error"></span>
                    </div>
                    </div>
                    
                  </div>
                  <div class="form-group<?php echo e($errors->has('JobLocation') ? ' has-error' : ''); ?>">
                    <label for="JobLocation" class="col-sm-2 col-md-2 control-label">Job Location</label>
                    <div class="col-sm-10 col-md-8">
                      <select name="JobLocation[]" id="JobLocation" class="form-control select2 " multiple="multiple" data-placeholder="Select a Job Location"
                          style="width: 100%;">
                       
                        <option>Dhaka</option>
                        <option>Gazipur</option>
                        <option>Khulna</option>
                        <option>Barisal</option>
                        <option>Rajshahi</option>
                        <option>Sylhet</option>
                        <option>Rangpur</option>
                    </select>
                     <?php if($errors->has('JobLocation')): ?>
                          <label class="help-block">
                              <strong><?php echo e($errors->first('JobLocation')); ?></strong>
                          </label>
                        <?php endif; ?>
                  </div>
                </div>
                <div class="form-group<?php echo e($errors->has('SalaryRange') ? ' has-error' : ''); ?>"> 
                    <label for="CompensationOtherBenifits" class="col-sm-2 col-md-2 control-label">Compensation & Other Benifits</label>
                      <label for="" class="col-sm-8 col-md-8">
                      <div>
                        <input name="SalaryRange" id="SalaryRange" value="1" type="radio" class="flat-red" <?php if (! empty(trim($__env->yieldContent('edit')))): ?> <?php if($SalaryRangeOption==1): ?> checked <?php else: ?> <?php endif; ?> <?php endif; ?>>
                          Negotiate
                      </div>
                      <div>
                        <input name="SalaryRange" id="SalaryRange" value="2" type="radio" class="flat-red" <?php if (! empty(trim($__env->yieldContent('edit')))): ?> <?php if($SalaryRangeOption==2): ?> checked <?php else: ?> <?php endif; ?> <?php endif; ?>>
                          Don't want to mention
                      </div>
                      <div>
                        <input name="SalaryRange" id="SalaryRange" value="3" type="radio" class="flat-red" <?php if (! empty(trim($__env->yieldContent('edit')))): ?> <?php if($SalaryRangeOption==3): ?> checked <?php else: ?> <?php endif; ?> <?php endif; ?>>
                          Want to display the following range
                      </div>
                      <div>
                      <label for="MinimumSalaryRange" class="control-label">MinimumSalaryRange</label>
                      <input name="MinimumSalaryRange" id="MinimumSalaryRange"  type="text" value="<?php echo $__env->yieldContent('MinimumSalaryRange'); ?>" class="form-control col-md-3 col-sm-3" placeholder="Minimum Salary Range">
                      </div>
                      <div>
                        <label for="MaximumSalaryRange" class="control-label">Maximum Salary Range</label>
                      <input name="MaximumSalaryRange" id="MaximumSalaryRange"  type="text" value="<?php echo $__env->yieldContent('MaximumSalaryRange'); ?>" class="form-control col-md-3 col-sm-3" placeholder="Maximum Salary Range">
                      </div>
                      
                    </label>
                  </div>
                  <div class="form-group">
                  <label for="SalaryDetails" class="col-sm-2 col-md-2 control-label">Salary Details</label>
                    <div class="col-sm-10 col-md-8">
                        <textarea name="SalaryDetails" id="SalaryDetails" class="form-control " placeholder="As per companey"><?php echo $__env->yieldContent('SalaryDetails'); ?></textarea>
                        <?php if($errors->has('SalaryDetails')): ?>
                          <label class="help-block">
                              <strong><?php echo e($errors->first('SalaryDetails')); ?></strong>
                          </label>
                          <?php endif; ?>
                      </div>
                  </div>
                  <div class="form-group">
                      <label for="OtherBenefits" class="col-sm-2 col-md-2 control-label">Other Benefits</label>
                      <div class="col-sm-10 col-md-8">
                       <textarea name="OtherBenefits" id="OtherBenefits" class="form-control" placeholder="As per companey"><?php echo $__env->yieldContent('OtherBenefits'); ?></textarea>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col-sm-offset-2 col-sm-10 col-md-8">
                      <button type="submit" class="btn btn-danger" id="post-job"><?php if (! empty(trim($__env->yieldContent('edit')))): ?>
                      Update Job 
                      <?php else: ?> 
                    Post Job 
                    <?php endif; ?>
                  </button>
                    </div>
                  </div>
                </form>
              </div>
<?php $__env->startPush('js'); ?>
<script type="text/javascript">
// var xyz=$('#JobLocation').find('#joblocation').val();
// console.log(xyz);
$('#post-job').on('click',function(){
var ExperienceRequired=$('#ExperienceRequired').val();
if (ExperienceRequired==1) {
  if ($('#MinimumExperience').val()=="" && $('#MinimumExperience').val()=="") {
      $('#ex-error').html('Please fill the required field!');
  }
}
});

</script>
<?php $__env->stopPush(); ?>            