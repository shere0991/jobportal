<?php echo $__env->make('admin.layouts.partial.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="wrapper">
<?php $__env->startSection('navbar'); ?>
<?php echo $__env->yieldSection(); ?>
<?php $__env->startSection('main-sidebar'); ?>
<?php echo $__env->yieldSection(); ?>
<div class="content-wrapper">
  <div class="container">
     <?php $__env->startSection('content-header'); ?>
     <?php echo $__env->yieldSection(); ?>
      <section class="content">
         <?php $__env->startSection('main-content'); ?>
         
         <?php echo $__env->yieldSection(); ?>
      </section>
  </div>
</div>  
<?php echo $__env->make('admin.layouts.partial.main-footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('control-sidebar'); ?>
<?php echo $__env->yieldSection(); ?>
</div>
<?php echo $__env->make('admin.layouts.partial.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
