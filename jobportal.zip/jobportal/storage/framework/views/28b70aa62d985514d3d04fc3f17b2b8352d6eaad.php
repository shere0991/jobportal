 <!-- Left side column. contains the sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
     
      <!-- search form -->
     
      <!-- /.search form -->
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">
        <li class="header">MAIN NAVIGATION</li>
       
        <li class="active"><a href="<?php echo e(url('admin/add-company')); ?>" class="text-red"><i class="fa fa-plus text-red"></i><span>Company</span></a></li> 
        <li><a href="<?php echo e(route('job-post.store')); ?>" class="text-green"><i class="fa fa-send text-green"></i><span>Post Job</span></a></li> 
        <li><a href="<?php echo e(url('admin/job-list')); ?>" class="text-aqua"><i class="fa fa-medium text-aqua"></i><span>Published Job</span></a></li> 
        <li><a href="<?php echo e(url('admin/archive-job')); ?>" class="text-yellow"><i class="fa fa-archive" aria-hidden="true"></i><span>Archived Job</span></a></li> 
        <li><a href="<?php echo e(url('admin/create-user')); ?>" class="text-red"><i class="fa fa-user"></i> <span>Create User</span></a></li>
        <li><a href="<?php echo e(url('admin/add-role')); ?>" class="text-aqua"><i class="fa fa-plus"></i> <span>Add Role</span></a></li>
         
        <li><a href="<?php echo e(url('admin/register-user')); ?>"><i class="fa fa-users text-green"></i><span>Register User</span></a></li>
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>