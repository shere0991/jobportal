<?php $__env->startSection('navbar'); ?>
<?php if(Auth::guest('admin')): ?>
<?php echo $__env->make('admin.layouts.partial.top-navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php else: ?>
<?php echo $__env->make('admin.layouts.partial.main-header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main-sidebar'); ?>
<?php if(Auth::user()->role()): ?>
<?php echo $__env->make('admin.layouts.partial.main-sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main-content'); ?>
<?php echo $__env->make('admin.job-post.create', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
       

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script type="text/javascript">
      // console.log('its works');
    // $(document).ready(function(){
      var x=$('.select2-selection__choice').text();
      console.log(x);
     // $.ajax({
     //  url:'',
     //  data:{'JobLocation':location,},
     //  dataType:'json',
     //  type:'post',
     //  processData: false,
     //  contentType: false,
     //  success:function(response){
     //    console.log(response);
            // if(response.data=='success'){
        //   $('#message').html('<div class="callout callout-success"><h4>Reminder!</h4>Record update successfully!</div>');
        //   $("#message").show().fadeOut(3000).queue(function(n) {   
        //   $(this).hide(); n();
        //   $('#example1').load(location.href+' #example1');
        //   });   
        // }
        // else{
        //   $('#message').html('<div class="callout callout-danger"><h4>Reminder!</h4>Record update failed!</div>');
        //   $("#message").show().fadeOut(3000).queue(function(n) {
        //   $(this).hide(); n();
        //   });  
        // }
        // $('#example1').load(location.href+' #example1');
    // console.log(response);
    //   },
    // });
// });
  </script>
<?php $__env->stopPush(); ?>  
<?php echo $__env->make('admin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>