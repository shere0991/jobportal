 <footer class="main-footer">
    <div class="container">
      <div class="pull-right hidden-xs">
        <b><a href="{{ route('admin.home') }}"> Job Portals</a></b>
      </div>
      <strong>Copyright &copy; 2017-2018 <a href="www.madinagroup.co">Madina Group</a>.</strong> All rights
      reserved.
    </div>
    <!-- /.container -->
  </footer>