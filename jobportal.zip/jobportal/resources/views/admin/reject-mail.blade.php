<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Reject</title>
</head>
<body>
<p><strong>Dear {{ $FirstName }} {{ $LastName }},</strong></p> 

<p>Thanks again for applying to join Madina Group  as Global Graduate- HR 11983BR. We also appreciate the time and effort you took to complete the online Culture Questionnaire.</p> 

<p>Having carefully considered your responses, we’re sorry to say we won’t be taking your application further on this occasion. We have a pretty unique culture and an important part of professional growth is making sure that you’re surrounded by people who share the same outlook as you. Unfortunately your responses indicated that, at this time, your thoughts about what makes a perfect culture aren’t quite the same as our own. </p>

<p>It’s a pity to miss out, but we wish you every success in your search for the right job, and appreciate the interest you’ve shown in British American Tobacco.</p> 

<p>With best wishes,</p>

<p>Madina Group of Industries</p>
</body>
</html>