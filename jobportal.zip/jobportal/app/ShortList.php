<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ShortList extends Model
{
    //
}
