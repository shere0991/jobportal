<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FinalList extends Model
{
    //
}
